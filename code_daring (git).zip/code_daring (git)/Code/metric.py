import numpy as np
from copy import deepcopy
import networkx as nx
import cdt
from cdt.metrics import retrieve_adjacency_matrix


def pre_pro (B_true, B_est) :
    B_est_l = deepcopy (B_est)
    B_est_u = deepcopy (B_est)
    d = B_true.shape [0]
    for i in range (d) :
        for j in range (i + 1, d) :
            if B_est [i, j] == 1 and B_est [j, i] == 1 :
                if B_true [i, j] == 1 :
                    B_est_l [i, j] = 0
                    B_est_u [j, i] = 0
                else :
                    B_est_u [i, j] = 0
                    B_est_l [j, i] = 0

    return B_est_l, B_est_u


def count_accuracy (B_true, B_est) :
    pred = np.flatnonzero (B_est)
    cond = np.flatnonzero (B_true)
    cond_reversed = np.flatnonzero (B_true.T)
    cond_skeleton = np.concatenate ([cond, cond_reversed])
    # true pos 
    true_pos = np.intersect1d (pred, cond, assume_unique=True)
    # false pos
    false_pos = np.setdiff1d (pred, cond_skeleton, assume_unique=True)
    # reverse
    extra = np.setdiff1d (pred, cond, assume_unique=True)
    reverse = np.intersect1d (extra, cond_reversed, assume_unique=True)
    # compute ratio
    pre = float (len (true_pos)) / max (len (pred), 1)
    rec = float (len (true_pos)) / max (len (cond), 1)
    shd = float (cdt.metrics.SHD (target=B_true, pred=B_est, double_for_anticausal=False))

    return {'pre': pre, 'rec': rec, 'shd': shd}


def evaluation (B_true, B_est) :
    true_labels = retrieve_adjacency_matrix (B_true)
    predictions = retrieve_adjacency_matrix (B_est, B_true.nodes () if isinstance (B_true, nx.DiGraph) else None)
    predictions_l, predictions_u = pre_pro (true_labels, predictions)

    SHD_l = count_accuracy (true_labels, predictions_l)
    SHD_u = count_accuracy (true_labels, predictions_u)
    SID = float (cdt.metrics.SID (target=true_labels, pred=predictions))

    return {'SHD_l': SHD_l, 'SHD_u': SHD_u, 'SID': SID}
